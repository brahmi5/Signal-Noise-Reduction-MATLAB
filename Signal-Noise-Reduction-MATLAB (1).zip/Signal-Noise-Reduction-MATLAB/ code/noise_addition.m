% Add Gaussian noise
noise = 0.5 * randn(size(x));
x_noisy = x + noise;

% Plot noisy signal
figure;
plot(t, x_noisy);
xlabel("Time (s)");
ylabel("Amplitude");
title("Noisy Signal");
grid on;
saveas(gcf, 'Signal-Noise-Reduction-MATLAB/results/noisy_signal.png');


