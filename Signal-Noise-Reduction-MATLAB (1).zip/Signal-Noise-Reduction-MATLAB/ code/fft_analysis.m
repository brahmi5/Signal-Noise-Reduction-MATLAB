% FFT analysis
N = length(x);
f_axis = Fs*(0:N-1)/N;

X = abs(fft(x));
X_noisy = abs(fft(x_noisy));
X_filt = abs(fft(x_filtered));

figure;
plot(f_axis, X_noisy, 'r');
hold on;
plot(f_axis, X_filt, 'b');
xlim([0 200]);
legend('Noisy','Filtered');
title("Frequency Domain Analysis");
xlabel("Frequency (Hz)");
ylabel("Magnitude");
grid on;
