% Low-pass filter design
fc = 100;                     % Cutoff frequency
[b, a] = butter(4, fc/(Fs/2), 'low');

% Filter the noisy signal
x_filtered = filtfilt(b, a, x_noisy);

% Plot comparison
figure;
plot(t, x, 'g', t, x_noisy, 'r', t, x_filtered, 'b');
legend('Original','Noisy','Filtered');
xlabel("Time (s)");
ylabel("Amplitude");
title("Signal Comparison");
grid on;
