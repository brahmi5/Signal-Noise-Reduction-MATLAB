clc;
clear;
close all;

% Signal parameters
Fs = 1000;          % Sampling frequency (Hz)
t = 0:1/Fs:1;       % Time duration (1 second)
f = 50;             % Signal frequency (Hz)

% Original signal
x = sin(2*pi*f*t);

% Plot time domain signal
figure;
plot(t, x);
xlabel("Time (s)");
ylabel("Amplitude");
title("Original Sine Wave Signal");
grid on;
