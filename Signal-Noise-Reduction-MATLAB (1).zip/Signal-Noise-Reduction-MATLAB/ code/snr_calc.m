snr_before = snr(x, x_noisy - x);
snr_after = snr(x, x_filtered - x);

fprintf('SNR before filtering: %.2f dB\n', snr_before);
fprintf('SNR after filtering: %.2f dB\n', snr_after);
